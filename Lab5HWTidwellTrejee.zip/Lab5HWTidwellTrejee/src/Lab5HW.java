
public class Lab5HW {

	public static boolean isValidSSN(String n) {
		
		if (n.length() != 9 && n.length() != 11)
			return false; 
		if (n.length()==11) {
			if (n.charAt(3) == '-' && n.charAt(6) == '-'|| n.charAt(3) == ' ' && n.charAt(6) == ' ')
				n = n.substring(0,3) + n.substring(4,6) + n.substring(7);
		} else {
				return false; 
		}
		if (n.length() == 9) {
			for(int a = 0; a < n.length(); a ++) {
				if(n.charAt(a) > '9' || n.charAt(a) < '0')
					return false; 
			}
			return true; 
		}
		return false;
	}
	
	public static String trim(String s) {
		String temp = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) != ' ') 
				temp += s.charAt(i); 
			else 
				if (temp.length() > 0) {
					if (s.charAt(i-1) != ' ')
						temp += s.charAt(i);
				}
			if (s.charAt(temp.length()- 1) == ' ')
				temp = temp.substring(0, temp.length());
				 
		}
		return temp;	 
	}
	public static void main(String[] args) {
		
		System.out.println(isValidSSN("109-87-6543"));
		
		System.out.println(isValidSSN("109 87 6543"));
		
		System.out.println(isValidSSN("109 87-6543"));
		
		System.out.println(isValidSSN("ppppppppppppp"));
		
		System.out.println(isValidSSN("109876543"));

		System.out.println(trim("Hi  what   is up"));
		
	}

}
