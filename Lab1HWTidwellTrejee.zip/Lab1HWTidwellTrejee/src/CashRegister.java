import java.util.Scanner;

public class CashRegister {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner cash = new Scanner(System.in);
		System.out.println("how many pennies");
		int Pennies = cash.nextInt();
		System.out.println("how many nickels");
		int Nickels =cash.nextInt();
		System.out.println("how many dimes");
		int dimes =cash.nextInt();
		System.out.println("how many quarters");
		int quarters =cash.nextInt();
		System.out.println("how many $1 bills");
		int Onebills =cash.nextInt();
		System.out.println("how many $5 bills ");
		int Fivebills =cash.nextInt();
		System.out.println("how many $10 bills");
		int Tenbills =cash.nextInt();
		System.out.println("how many $20 bills");
		int twenty =cash.nextInt();
		
		
		double pworth = 0.01,
			   nworth = 0.05,
			   dworth = 0.10,
			   qworth = 0.25,
			   oworth = 1.00,
			   fworth = 5.00,
			   tworth = 10.00,
			   tyworth = 20.00;
	double cointotal =Pennies*pworth + Nickels*nworth + dimes*dworth + quarters*qworth;
double bill_total = Onebills*oworth + Fivebills*fworth + Tenbills*tworth + twenty*tyworth;
		System.out.println("coin total:"+cointotal);
		System.out.println("bill total:"+bill_total);
		double total= cointotal+bill_total;
		System.out.println("total:" + total);


				

	}
}
