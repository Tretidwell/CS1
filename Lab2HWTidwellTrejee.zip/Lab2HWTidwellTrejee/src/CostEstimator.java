import java.util.Scanner;
public class CostEstimator {

	public static void main(String[] args) {
// Create Scanner Object
		Scanner input = new Scanner(System.in);
	
// Room attributes
		System.out.print("what is the length of the room?: " );
		double length = input.nextDouble(); // In foot
		
		System.out.print("what is the width of the room?: ");
		double width = input.nextDouble(); // In Foot
		
		System.out.print("what is the height of the room?: ");
		double height = input.nextDouble(); // In foot 
		
//wall area 
		double wall_area = length*height; 
		System.out.print(wall_area);
		
		
// Door's Width and height 
		System.out.print("\nwhat is the door's width?: ");
		double doorWidth = input.nextDouble();
		
		System.out.print("what is the door's height?: ");
		double doorHeight = input.nextDouble();
		
		double door_area = doorWidth*doorHeight; 
		System.out.print( "Door area: " + door_area);
		
// Window's width and height
		System.out.print("\nwhat is the window's width?: ");
			double windowWidth = input.nextDouble();
		
		System.out.print("what is the window's height?: ");
			double windowHeight = input.nextDouble();
			double Window_area = windowWidth * windowHeight; 
		System.out.println(" Window Area: " + Window_area);
		
//standard or double paint
			 final double standardPaint= 14.99,
				 	      deluxePaint= 29.99;
		System.out.print("Standard paint cost $"+ standardPaint + " Deluxe paint cost $" + deluxePaint +".");
		System.out.print("\nwhat type of paint, 1.) standard or 2.) deluxe?: ");
		int paintType = input.nextInt();
			if (paintType == 1)    {
				System.out.println("Standard");
			} else {
				System.out.print("Deluxe");
			}
 /*
 	one can of paint covers 250^2 ft 
 	area = length*height
 	double wall_area = length*height;
 	double door_area = doorWidth*doorHeight;
 	double Window_area = windowWidth * windowHeight; 
 	double wall_area = length*height;
 */
 		//paint cans needed
 		double  W_Darea = wall_area - door_area,
 				W_Warea = wall_area - Window_area, 
 				WallwDW_area = W_Darea + W_Warea,
 				Area_walls= WallwDW_area + wall_area + wall_area ;
 		System.out.println("area of the wall with the door:" + W_Darea);
 		System.out.println("area of the wall with the window"+W_Warea);
 		System.out.println("area" + WallwDW_area);
 		System.out.println(Area_walls);
 		
 		int pCoverage = 250,
 			pCans = (int)Area_walls / pCoverage; 
 		
 		System.out.println(pCans);
 		System.out.println("you need " + pCans +" of paint");
 //total and stuff 
 		if (paintType == 1)    {
			double subtotal = pCans*standardPaint;
			System.out.println("Subtotal: $" + subtotal);
			double tax = 0.0925*subtotal; 
			System.out.println("tax: $" + tax );
			double total = tax + subtotal; 
			System.out.println("total: $" + total);
		} else {
			double subtotal = pCans*deluxePaint;
			System.out.println(" Subtotal: $" + subtotal);
			double tax = 0.0925*subtotal; 
			System.out.println("tax: $" + tax );
			double total = tax + subtotal; 
			System.out.println("total: $" + total);
			
		}
	}
}