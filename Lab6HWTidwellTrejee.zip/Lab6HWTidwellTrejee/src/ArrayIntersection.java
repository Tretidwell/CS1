import java.util.*; 
public class ArrayIntersection {

	public static void intersection(int[] a1, int[] a2) { 
		List<Integer> temp = new ArrayList<Integer>();
		for (int i = 0; i < a1.length; i ++) {
			
			for(int j = 0; j < a2.length; j ++) {
				
				if(a1[i] == a2[j]) {
					if(!temp.contains(a1[i])) {
						temp.add(a1[i]);
					}
						
				}
			}
		}
		
		System.out.println("Comman Elements Are As Follows:");
		for(Integer i:temp)
			System.out.print(i+",");
		System.out.println("\nThe number of comman elements are the following:"+temp.size());
	}
	public static void main(String[] args) {
		int[] a1 = {0, 1, 2, 3, 9};
		int[] a2 = {2, 4, 6, 8, 10};
		
		intersection(a1,a2);

	}
	

}
