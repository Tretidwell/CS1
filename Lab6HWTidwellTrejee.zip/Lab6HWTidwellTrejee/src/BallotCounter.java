import java.util.Scanner; 
public class BallotCounter {

	public static void main(String[] args) {
		Scanner A = new Scanner(System.in);
			
			int IdNum = 0;
			int bCounter[] = new int[1000];
			
				while(true) { 
					System.out.println("Enter Canidate ID# (0-999), negative # to exit: " );
						IdNum = A.nextInt();
						
						if (IdNum < 0 )
							break;
						
						else if (IdNum > 999)
							System.out.println("must be a number between 0 & 999");
						
						else {
							
							System.out.println( " provide # of votes for canidate " + IdNum + ": ");
								int votes = A.nextInt();
								bCounter[IdNum] = votes;
							}
						}
				System.out.println(" results         # of votes");
				
					for( int i = 0; i < 1000; i ++) {
						if ( bCounter[i] > 0)
							System.out.println("Canidate #" + i +":" + "         "+ bCounter[i]);
					}
					
	}
}


