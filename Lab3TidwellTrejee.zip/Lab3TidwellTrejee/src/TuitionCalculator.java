import java.util.Scanner;

public class TuitionCalculator {

	public static void main(String[] args) {
	 Scanner hours = new Scanner(System.in);
//User inputs
		System.out.print("How many credit hours are you taking in total?: ");
			int totalHours = hours.nextInt();  
		System.out.print("How many credit hours are from Engr/Sci courses?: ");
			int engScienceHours = hours.nextInt(); // 
		System.out.println("\nSummary of Charges:\n---------------------");
//summary of Charges 
		
		
		int totalTuition;
		int credithrsPass12;
		int creditHoursUpTo12; // $400 Per Credit Hour Up to 12 PRICE
		int engSciHrs = 25*engScienceHours; // $25 per E/S credit hour PRICE
		
		if (totalHours <= 12) {
			creditHoursUpTo12 = 400 * totalHours; // Less Than 12 Hours(Conditional) Times Input hours
			engSciHrs = 25 * engScienceHours; // Same as above^
			totalTuition = engSciHrs + creditHoursUpTo12;
			
			System.out.println("$400 per credit hr: $" + creditHoursUpTo12);
			System.out.println("$25 per E/S credit hour: $" + engSciHrs);
			System.out.println("TOTAL: $" + totalTuition);
		}
		
		else if (totalHours > 12) {
			credithrsPass12 = 60*(totalHours-12);
			engSciHrs = 25*engScienceHours; 
			totalTuition = engSciHrs + credithrsPass12 + 4800;
			System.out.println(" $400 per credit hr: $" + 4800); // Why total hours minus 12? --- Print b_hours instead of t_hours-12
			//int bonusHours = totalHours - 12;  // It would make more sense to print b_hours on line 19 instead of t_hours - 12
			System.out.println("$60 per credit hr > 12: $" + credithrsPass12); 
			System.out.println( "$25 per E/S credit hr: $" + engSciHrs + "\n");
			System.out.println("TOTAL: $" + totalTuition);
		}
		
	}
}
