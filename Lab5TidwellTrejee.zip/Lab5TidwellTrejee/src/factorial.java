import java.util.Scanner; 
public class factorial {

	public static int factorial(int n) {
		if (n == 0 || n < 0)
			return 1; 
		else 
			return n*factorial(n-1);
	}
	public static void main(String args[]) {
		Scanner red = new Scanner(System.in);
		System.out.println("Please enter an integer: ");
			int digit = red.nextInt();
			
		//checks factorial 
			
		System.out.println(factorial(5));
		
		//user input 
		
		System.out.print(factorial(digit));
	}
}