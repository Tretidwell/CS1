import java.util.Scanner; 
public class Parking {

	public static int minutes(int a) {
		Scanner blue = new Scanner(System.in);
		int minutes= blue.nextInt();
		int cost = 0;
		int addCost; 
		if (minutes <= 30) {
			cost = 0;
			return cost;
		}
		else if (minutes > 30 && minutes <= 60 ) {
			cost = 2; 
			return cost; 
		}
		else if (minutes > 60 && minutes <= 720) {
			addCost = (minutes - 60)/30;
					if (((minutes - 60) % 30) != 0) { 
						addCost = 1 + addCost; 
						cost = 2 + addCost; 
						return cost;
					}
		} else if (minutes > 720 && minutes <= 1440) {
			cost = 24; 
			return cost;
		} else if (minutes > 1440) {
			addCost = 24*minutes/1440; 

		}
		return cost;		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner blue = new Scanner(System.in);
			int x; 
			for (x =0; x <=6; x++ ) {
			System.out.println(" How long have you been parked(in minutes): ");
				int time = blue.nextInt();
			System.out.println(minutes(time));
			}
	}

}
