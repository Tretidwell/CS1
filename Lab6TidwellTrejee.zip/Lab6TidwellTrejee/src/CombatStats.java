import java.util.Scanner; 
public class CombatStats {

	public static void main(String[] args) {
		Scanner a = new Scanner (System.in);
		double sum=0;
		
		System.out.println(" Enter the number of values avaliable: ");
		
			int values = a.nextInt();
			double [] userValues = new double[values];
		
			double average = 0.0;
			
		System.out.println("Enter " + values + " values");
		for ( int i = 0; i < values; i++) {
			userValues[i] = a.nextDouble();
			sum=sum+userValues[i];
		}
		
		average=sum/userValues.length;
		double minimum = userValues[0];
		double maximum = userValues[0];
		
		for ( int i = 0; i < values; i++) {
			if(minimum>userValues[i])
				minimum=userValues[i];
			if(maximum<userValues[i])
				maximum=userValues[i];
		}
//			if (userValues[i] < userValues[i++]) {
//				minimum = userValues[i];
//				maximum = userValues[i++];
//			} else {
//				minimum = userValues[i++];
//
//			}

	
		
		System.out.println("minimum: " + minimum);
		System.out.println("maximum: " + maximum);
		System.out.println("average: " + average);
  }
}
