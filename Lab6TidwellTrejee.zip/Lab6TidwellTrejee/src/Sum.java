import java.util.Scanner; 
public class Sum {

	public static void main(String[] args) {
		Scanner b = new Scanner (System.in);
		int[] myArray = new int[5]; 
		int total = 0;
		
			System.out.print("Enter " + myArray.length + " values: ");
			for (int i = 0; i < 5; i ++ ) {
				myArray[i] = b.nextInt();
				if(i%2==0)
					total=total+myArray[i];
				else
					total=total-myArray[i];
			}
			/* i equals the index and only the 1st and 3rd index will be subtracted and they are not prime 
			 * that explains the use of i%2.
			 */	
			System.out.print(total);

	}

}
