import java.util.Scanner; 
public class GPACalulator {

	public static void main(String[] args) {
Scanner s = new Scanner(System.in);

   int totalClasses = 0;
   int creditHours = 0;
   int classcreditHours = 0;
   double classGrade = 0; 
   String classLetter = ();
  
		System.out.print(" How many classes did you take:");
			 totalClasses = s.nextInt();
		
		System.out.print(" How many credit hours did you take:");
			 creditHours = s.nextInt();
			
		if (totalClasses > 0) {
			System.out.println("Class 1: Number of credit hours?");
					 classcreditHours = s.nextInt();
					System.out.println(" Class 1: final numerical grade?");
					 classGrade = s.nextDouble();
			System.out.println("Class 2: Number of credit hours?");
						classcreditHours = s.nextInt();
				   System.out.println(" Class 2: final numerical grade?");
			 			classGrade = s.nextDouble();
			System.out.println("Class 3: Number of credit hours?");
						classcreditHours = s.nextInt();
			       System.out.println(" Class 3: final numerical grade?");
			       		classGrade = s.nextDouble();
			System.out.println("Class 4: Number of credit hours?");
						classcreditHours = s.nextInt();
			       System.out.println(" Class 4: final numerical grade?");
			       		classGrade = s.nextDouble();
		}
		if (classGrade >=90) 
			 classletter = "A";
		if (classGrade < 90 || classGrade >= 80)
			 classletter = "B";
		if (classGrade < 80 || classGrade >= 70)
			 classletter = "C";
		if (classGrade < 70 || classGrade >= 60)
			 classletter = "D";
		if (classGrade < 60)
			 classletter = "C";
	
	}

}
