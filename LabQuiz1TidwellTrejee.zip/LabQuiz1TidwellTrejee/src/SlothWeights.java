import java.util.Scanner;
public class SlothWeights {

	public static void main(String[] args) {
Scanner s = new Scanner(System.in);
//variables
int slothWeight = 0;
int atriskSloths = 0;
int avgatriskSloths = 0;
int notatrisk = 0;
		System.out.print("Enter the weight in lbs of this sloth:");
			 slothWeight = s.nextInt();
		System.out.print(" Would you like to entor more data? (1 = yes 2 = no)");
			int moreData = s.nextInt();
			while(moreData == 1 ) {
				switch (moreData) { 
				case 1: System.out.println("Enter weight in lbs of this sloth");
						slothWeight = s.nextInt();
						if (slothWeight < 0) {
							System.out.println("**Error ** can't be a negative value");
							System.out.println("Enter weight in lbs of this sloth");
							slothWeight = s.nextInt();
						} if (slothWeight < 3) {
							atriskSloths ++;
						}
						System.out.print(" Would you like to entor more data? (1 = yes 2 = no)");
						 moreData = s.nextInt();
				case 2: break;
				}
			}
				if (slothWeight < 3)
					atriskSloths ++;
				
				if (slothWeight > 3)
					notatrisk ++;
					
				if (atriskSloths == 0) {
					avgatriskSloths = 0;
				} else {
					avgatriskSloths = (atriskSloths*slothWeight);
				} 
				if (notatrisk == 0) {
					notatrisk = 0;
				} else {
					notatrisk = (notatrisk*slothWeight);
				} 
			System.out.println("Number of at-risk sloths:" + atriskSloths);
			System.out.println("Average of at-risk weight:" + avgatriskSloths);
			System.out.println("Average not-at-risk weight:" + notatrisk);
			/*switch (moreData) { 
				case 1: System.out.println("Enter weight in lbs of this sloth");
						slothWeight = s.nextInt();
						if (slothWeight < 0) {
							System.out.println("**Error ** can't be a negative value");
						}
				case 2: break;
			}
		*/

	}
	
}
