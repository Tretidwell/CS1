import java.util.Scanner; 

public class Car {
	public static String makeandModel;
	public static String color;
	public static double price;
	public static double mileage; 
	
	Car( ) {
	makeandModel = "Nissan Sentra";
	color = "red";
	price = 2000;
	mileage = 0;
}
	public Car( String a, String b, double c){
		makeandModel = a;
		color = b;
		price = c; 
		mileage = 0; 
		
	}

public void setPrice(double p) {
	price = p;
}

public void paint(String b) {
	
	color = b;
}

public void displayCarInfo() {
	System.out.println( "Make and Model: " + makeandModel);
	System.out.println( "Color: " + color);
	System.out.println( "Price: " + price);
	System.out.println( "Mileage " + mileage);
}

public void travel(double distance) {
	double distanceTraveled = distance;
	mileage = mileage + distanceTraveled; 
 }
}
	
