
public class Die {

	private static int sides;
	private static int i;
	
	public static int getSides() {
		return sides; 
	}
	
	public static int getI() {
		return i; 
	}

	Die(int j ) {
		sides = j; 
		i= 0;
	}
	
	public static void roll(int s) {
		
		for(i = 0; i < s; i++) {
		int number= Math.random(20) + 1;
		
		
		
		}
		return number;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
