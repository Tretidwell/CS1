import java.util.Scanner; 
public class CarClient {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Car car1= new Car("Porsche Cayman S", "Black", (double)63800);
		Car car2= new Car("Nissan Leaf","blue",(double)29010);
		
		car1.displayCarInfo();
		car2.displayCarInfo();
		
		
		car1.paint("purple");
		car2.paint("green");
		
		
		car1.travel((double)12000);
		car2.travel((double)8000);
		
		car1.setPrice((double)50000);
		car2.setPrice((double)24500);
		
		car1.displayCarInfo();
		car2.displayCarInfo();
		

	}

}
