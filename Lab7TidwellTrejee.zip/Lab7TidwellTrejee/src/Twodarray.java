
public class Twodarray {

	public static double averagePPG(int[][]scores,int p) {
		int row = p; 
		double pointsScored = 0; 
		
			for(int i=0; i < scores[row].length;i ++) {
				pointsScored = pointsScored + scores[row][i];
			}
		double playerAvg = (pointsScored/scores[row].length);
		
		return playerAvg; 
	}
	
	public static int singleGameScore(int[][]scores, int g) {
		int column = g; 
		int pointsScored = 0; 
		
			while (column < scores.length) {
				pointsScored = pointsScored + scores[column][g];
					
				column ++;
			}
			return pointsScored; 
		
	}
	
	public static double averageGameScore(int[][] scores) {
		int row = 0, 
			column = 0,
			gameTotal = 0,
			avgGameTotal = 0; 
		while (column < scores[0].length) {

			while (row < scores.length) {

				gameTotal = gameTotal + scores[row][column];

				row++;

			}

			avgGameTotal = avgGameTotal + gameTotal;

			gameTotal = 0;

			row = 0;

			column++;



}



		avgGameTotal = (avgGameTotal / (scores[0].length));



		return avgGameTotal;
	}
	
	public static int singleGameTopScoringPlayer(int[][] scores, int g ) {

			int HighestScoringPlayer = 0;

			int row = 0;

			int maxValue = scores[row][g];

			int nextrow = row + 1;

			while (nextrow < scores.length) {

				if (maxValue < scores[nextrow][g]) {

					maxValue = scores[nextrow][g];

					HighestScoringPlayer = nextrow;

				}

				nextrow++;

			}

			return HighestScoringPlayer;
	}
	
	public static void main(String[] args) {
		int [][] bBallStats = { { 20, 27, 16, 23, 20, 27, 18 },

				{ 8, 18, 14, 17, 9, 12, 0 }, { 38, 19, 25, 22, 19, 25, 31 },

				{ 17, 8, 11, 21, 15, 0, 9 }, { 2, 1, 3, 0, 10, 2, 4 } };

	
	int i = 0;
	
		for (int j = 0; j < bBallStats[i].length; j++) {
			System.out.print(bBallStats[i][j] + "\t");
		}
		System.out.println();

	System.out.println("Top the Inept: "+ averagePPG(bBallStats, 4));

	System.out.println("Game Total: "+singleGameScore(bBallStats, 1));

	System.out.println("AVG Team Score: "+averageGameScore(bBallStats));

	System.out.println("Top Scorer Index: "+singleGameTopScoringPlayer(bBallStats, 2));

}
	}