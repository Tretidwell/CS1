import java.util.Scanner;
public class Paycheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner Paycheck = new Scanner(System.in);
		System.out.println("Hours worked?");
		double hours = Paycheck.nextDouble(); 
		System.out.println("Hourly pay?");
		double hourlyPay = Paycheck.nextDouble();
		System.out.println("Federal tax rate (%)?");
		double Fedtax = Paycheck.nextDouble();
		System.out.println("Other deductions? ");
		double Deduct = Paycheck.nextDouble();
	
	//figure out how to convert whole number into decimals/ percent
	
	double Gross_pay = hours*hourlyPay; 
	double Federal_tax = Fedtax*Gross_pay;
	double Deductions = Federal_tax + Deduct;
	double Net_pay = Gross_pay - Deductions;
	double total_deductions = Deductions;
	
		System.out.println("hours worked:" + hours);
		System.out.println("hourly pay:" + hourlyPay);
		System.out.println("federal tax rate (%):" + Fedtax);
		System.out.println("other deductions:" + Deduct);
		
		System.out.println("Gross pay:" + Gross_pay);
		System.out.println("Deductions: \n Federal tax:$"+ Fedtax + "\n Other Deductions:$"+ Deduct + "\n Total Deductions:$"+ total_deductions);
		System.out.println("Net Pay:$" + Net_pay);
		
	}

}
