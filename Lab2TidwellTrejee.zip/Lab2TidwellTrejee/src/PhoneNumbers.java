import java.util.Scanner;
public class PhoneNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner Number= new Scanner(System.in); 
	System.out.println("enter a 10 digit phone number(no spaces or dashes)" );
	long phone_number = Number.nextLong();
	System.out.println(phone_number);
	long area_code = phone_number/10000000;
	long rest = phone_number%10000000;
	System.out.println("Area code:" + area_code);
	System.out.println("Number:" + rest);
	
	}

}
