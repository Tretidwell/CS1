import java.util.Scanner; 
public class HikingForSloths {

	public static boolean isLevel(double [] elevation) {
		
		
		double highPoint = 0,
			   lowPoint = 0,
			   tempPoint= 0;
		
		for (int i = 0; i < elevation.length; i ++) {
			
			if (elevation[i] < lowPoint ) 
				lowPoint = elevation[i]; 
			
			if (elevation[i] > lowPoint)
				highPoint = elevation[i]; 
		}
			double difference = highPoint - lowPoint;
			
			if (difference <= 50) 
				return true; 
			else {
				return false;
			}
			
	}
	
	public static boolean isChallenging(double [] elevation ) {
		
		double highPoint = 0,
				lowPoint = 0,
				tempPoint= 0;
		
		for (int i = 0; i < elevation.length; i ++) { 
			
			if (elevation[i] < lowPoint ) 
				lowPoint = elevation[i]; 
			
			if (elevation[i] > lowPoint)
				highPoint = elevation[i]; 
			
			tempPoint = elevation[i] - elevation[i+1]; 
			if (tempPoint > 100 || tempPoint < -100)
				 break;
				}
		return true;
	}
	
	public static void main(String[] args) {
		double[] elevation = {57.3, 270.0, -4.1, 528.3, 143.8};
		System.out.println(isLevel(elevation));
		System.out.println(isChallenging(elevation));
	}

}
