
public class TotallyNotPacman {
	
	static void displayBoard(int board[][]) {

		for(int row = 0; row < board.length; row++) {

			for(int col = 0; col < board[row].length; col++)

				System.out.printf("%3d", board[row][col]);

			System.out.println();

		}

	}




	static boolean underThreat(int board[][]) {

	boolean threatStatus = false;
	
	int mainCharacterRow = -1, mainCharacterCol = -1;

	int threatC = 0;

		for(int row = 0; row < board.length; row++) {

			for(int col = 0; col < board[row].length; col++) {

				if(board[row][col] == 3) {
					mainCharacterRow = row;
					mainCharacterCol = col;
				}
			}
	}
		
		if(mainCharacterRow == 0 && mainCharacterCol == 0) {

			if(board[mainCharacterRow][mainCharacterCol+1] == 2)

				threatC++;
			if(board[mainCharacterRow+1][mainCharacterCol] == 2)

				threatC++;
			if(board[mainCharacterRow+1][mainCharacterCol+1] == 2)

				threatC++;
		}

		else if(mainCharacterRow == 0 && mainCharacterCol == board[0].length -1) {
			
			if(board[mainCharacterRow][mainCharacterCol-1] == 2)

				threatC++;
			if(board[mainCharacterRow+1][mainCharacterCol] == 2)

				threatC++;
			if(board[mainCharacterRow+1][mainCharacterCol-1] == 2)

				threatC++;

	}

		else if(mainCharacterRow == board.length -1 && mainCharacterCol == 0) {

			if(board[mainCharacterRow-1][mainCharacterCol] == 2)

				threatC++;

			if(board[mainCharacterRow][mainCharacterCol+1] == 2)

				threatC++;

			if(board[mainCharacterRow-1][mainCharacterCol+1] == 2)

				threatC++;

		}


		else if(mainCharacterRow == board.length -1 && mainCharacterCol == board[0].length -1) {

			if(board[mainCharacterRow-1][mainCharacterCol] == 2)

				threatC++;

			if(board[mainCharacterRow][mainCharacterCol-1] == 2)

				threatC++;

			if(board[mainCharacterRow-1][mainCharacterCol-1] == 2)

				threatC++;

	}



		else if(mainCharacterRow == 0) {


			if(board[mainCharacterRow][mainCharacterCol-1] == 2)

				threatC++;

			if(board[mainCharacterRow][mainCharacterCol+1] == 2)

				threatC++;

			if(board[mainCharacterRow+1][mainCharacterCol] == 2)

				threatC++;

			if(board[mainCharacterRow+1][mainCharacterCol-1] == 2)

				threatC++;

			if(board[mainCharacterRow+1][mainCharacterCol+1] == 2)

				threatC++;

	}
		
		
		else if(mainCharacterRow == board.length-1) {

			if(board[mainCharacterRow][mainCharacterCol-1] == 2)
				
				threatC++;

			if(board[mainCharacterRow][mainCharacterCol+1] == 2)

				threatC++;

			if(board[mainCharacterRow-1][mainCharacterCol] == 2)

				threatC++;

			if(board[mainCharacterRow-1][mainCharacterCol-1] == 2)

				threatC++;

			if(board[mainCharacterRow-1][mainCharacterCol+1] == 2)
			
				threatC++;

	}

		else if(mainCharacterCol == 0) {

			if(board[mainCharacterRow-1][mainCharacterCol] == 2)

				threatC++;

			if(board[mainCharacterRow+1][mainCharacterCol] == 2)

				threatC++;

			if(board[mainCharacterRow][mainCharacterCol+1] == 2)

				threatC++;

			if(board[mainCharacterRow-1][mainCharacterCol+1] == 2)
				threatC++;
			if(board[mainCharacterRow+1][mainCharacterCol+1] == 2)

				threatC++;
		}

	else if(mainCharacterCol == board[0].length-1) {

		if(board[mainCharacterRow-1][mainCharacterCol] == 2)
			threatC++;

		if(board[mainCharacterRow+1][mainCharacterCol] == 2)

			threatC++;

		if(board[mainCharacterRow][mainCharacterCol-1] == 2)

			threatC++;

		if(board[mainCharacterRow-1][mainCharacterCol-1] == 2)
			
			threatC++;

		if(board[mainCharacterRow+1][mainCharacterCol-1] == 2)

			threatC++;

	}

	else if(mainCharacterRow != -1 && mainCharacterCol != -1) {

		if(board[mainCharacterRow-1][mainCharacterCol] == 2)

			threatC++;

		if(board[mainCharacterRow+1][mainCharacterCol] == 2)
			
			threatC++;

		if(board[mainCharacterRow][mainCharacterCol-1] == 2)

			threatC++;
		if(board[mainCharacterRow][mainCharacterCol+1] == 2)

			threatC++;

		if(board[mainCharacterRow-1][mainCharacterCol-1] == 2)

			threatC++;

		if(board[mainCharacterRow-1][mainCharacterCol+1] == 2)

			threatC++;

		if(board[mainCharacterRow+1][mainCharacterCol-1] == 2)

			threatC++;

		if(board[mainCharacterRow+1][mainCharacterCol+1] == 2)

			threatC++;

	}

		if(threatC >= 2)

			threatStatus = true;	

		return threatStatus;

	}

	public static void main(String[] args) {

	int board[][] = {{1,1,2,1,0,1,1}, {1,1,0,2,0,1,1}, {1,0,0,1,1,1,1}, {1,0,1,0,0,0,1},

	{1,0,1,0,1,0,1}, {0,3,0,2,1,0,1}};


	displayBoard(board);

		if(underThreat(board))

			System.out.println(" Uner Threat");

		else

			System.out.println(" Not Under Threat");

		}

	}

