import java.util.Arrays;
import java.util.Scanner;

public class lab7hwTidwellTrejee {

	public static final String [][] names = {
			 {"Dwight", " Eisenhower"},
			 {"John"," Kennedy"},
			 {"Lyndon"," Johnson"}, 
			 {"Richard"," Nixon"},
			 {"Gerald"," Ford"},
			 {"James"," Carter"},
			 {"Ronald"," Reagan"},
			 {"George"," Bush"},
			 {"Bill"," Clinton"},
			 {"George"," Bush"},
			 {"Barack"," Obama"},
			 {"Donald"," Trump"}
	 };
	public static void orderLastname(String [][] names) {
		int n;
		String temp = null,
			   temp1= null;
		int y = 1; 
		
		
		for (int j = 0; j < names.length-1; j++) {
			
			for (int i = 1; i < names.length; i++) {
				
				if ((names[i][1]).compareToIgnoreCase(names[j][i+1]) < 0) {
					
					temp = names[i][0];
					names[i][0] = names[j][0];
					names[j][0] = temp;
					
					temp = names[i][1];
					names[i][1]= names[j][1];
					names[j][1]=temp; 
				} else if ((names[i][1]).compareTo(names[j][1]) == 0){
					
					if(names[i][0].compareTo(names[j][0]) == 0){
						
						 temp = names[i][0];
	                       names[i][0] = names[j][0];
	                       names[j][0] = temp;
	                       
	                       temp = names[i][1];
	                       names[i][1] = names[j][1];
	                       names[j][1] = temp;
					}
						
				}
			
				
			}
		}
	}
	public static void main(String[] args) {
		
		System.out.print(orderLastname(names));
		
		
		

	}

}
