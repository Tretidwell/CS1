import java.util.Scanner;
public class RetirementCalculator {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
//variables 
		double interest_rate = 0, 
			starting_balance = 0,
			target = 0,
			y_Contribution = 0,
			interest = y_Contribution*interest_rate,
			balance = 0,
			end_balance = 0;
//for one year 
		System.out.print("Starting balance: ");
			starting_balance = s.nextDouble();
		System.out.print("Target balance @ 65yo: ");
			target = s.nextDouble();
		System.out.print("planned yearly contribution: ");
			y_Contribution = s.nextDouble();
		System.out.print(" Interest rate (in decimal form): ");
			interest_rate = s.nextDouble();
		System.out.print(" your current age: ");
			int current_age = s.nextInt();
// variables for loop 
//			interest = starting_balance*interest_rate;
//			end_balance = interest + y_Contribution + starting_balance;
//			starting_balance = end_balance; 
		
		//first while loop
		/* set starting_balance to end _balance to ensure the next iteration of the loop starts off
		 * at the right value, the last total(end_balance)
		 * 
		 */
			int y = 1; 
			int years = 0;
			double tempend = 0;
		while (tempend <= target) {
			tempend = starting_balance;
			interest = (interest_rate*starting_balance);
			years = 65 - current_age; 
			y = 1;
			while(y <= years) {
				double tempinterest = (interest_rate*tempend);
				tempend += tempinterest;
				//System.out.println(tempend);
				y++;
			}
			//if(tempend >= target)
				
			System.out.println("Money from Interest: $ " + interest);
			if(tempend <= target)
				end_balance = interest + starting_balance + y_Contribution;
			else
				end_balance = interest + starting_balance;
			System.out.println("new total: $ " + end_balance);
			starting_balance = end_balance; 
			current_age++; 
			System.out.println("At "+ current_age + " your balance will be $ " + starting_balance);
			System.out.println();
			
		}
		
		while (current_age < 65) {
			interest = (interest_rate*starting_balance);
			System.out.println("Money from Interest: $ " + interest);
			end_balance = interest + starting_balance;
			System.out.println("new total: $ " + end_balance);
			starting_balance = end_balance; 
			current_age++; 
			System.out.println("At "+ current_age + " your balance will be $ " + starting_balance);
			System.out.println();
		}
			
	}

}
