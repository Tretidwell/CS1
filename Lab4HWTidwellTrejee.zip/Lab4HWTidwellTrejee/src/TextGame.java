import java.util.Scanner; 
public class TextGame {

	public static void main(String[] args) {
Scanner way = new Scanner(System.in);

	int x = 0,
		y = 0;
	System.out.println("Welcome to Text Grid");
	System.out.println("--------------------------");
	System.out.println();
	System.out.println(" You are currently at" + "("+ x + "," + y + ")");
	
	int directions = 0;

	while (directions < 6 ) {
	System.out.println("Awaiting command ( 1 = north, 2 = east, 3 = south , 4 = west, 5 = exit )");
		 directions = way.nextInt();
	switch (directions) {
		case 1: x = (x + 1) ;
			System.out.println(" Moving North");
			System.out.println( "(" + x +","+ y +")" );break;
		case 2: y = (y + 1) ;
			System.out.println(" Moving East");
			System.out.println( "(" + x +","+ y +")" );break;
		case 3: x = (x - 1);
			System.out.println(" Moving South ");
			System.out.println( "(" + x +","+ y +")" );break;
		case 4: y = (y - 1);
			System.out.println(" Moving West ");
			System.out.println( "(" + x +","+ y +")" );
		}
	if (directions == 5) {
	System.out.println("End of Game!!! ");
	System.out.println("Would you like to start a new game?");
	}

	 	}
	}
	
	

}

